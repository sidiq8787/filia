# Translation

Some groups may prefer use their language instead of english or indonesia.
Now you can add your language to Emilia bot without recoding.

Just open [this link](https://www.transifex.com/emilia-bot/emilia-translation/dashboard/) and happy translating!

## Contributors

The following people has contributors for some languages, you have my thanks for this.
Without them Emilia now can speak their language as well.

If you find there was some typos in languages, don't blame this people, just edit and update your language [in here](https://www.transifex.com/emilia-bot/emilia-translation/dashboard/).
Contributor are welcome to everyone!

-   **Indonesia** - [Ayra Hikari](https://telegram.me/AyraHikari)
-   **English** - [Ayra Hikari](https://telegram.me/AyraHikari)

# Added more language

If you want to translate, but your language is not in list, please contact me in:

-   [Telegram](https://telegram.me/AyraHikari)
-   [Email](mailto:ayrahikari@linuxmail.org)

